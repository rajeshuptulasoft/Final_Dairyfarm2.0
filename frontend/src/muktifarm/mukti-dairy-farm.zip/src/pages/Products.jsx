import { useState } from "react";
import ProductCard from "../components/ProductCard";
import EnquiryModal from "../components/EnquiryModal";
import "../css/products.css";

const PRODUCTS = [
  {
    name: "Fresh Cow Milk",
    emoji: "🥛",
    description:
      "Hand-bottled within hours of milking. Creamy, naturally sweet and full of cream.",
    tags: ["Organic", "Glass Bottled", "Daily"],
    fresh: true,
  },
  {
    name: "Set Curd",
    emoji: "🥣",
    description:
      "Thick, slow-cultured curd made from full-cream milk using traditional methods.",
    tags: ["Probiotic", "No Additives"],
  },
  {
    name: "Farm Paneer",
    emoji: "🧀",
    description:
      "Soft, fresh paneer made the same morning with just milk and lemon — nothing else.",
    tags: ["Fresh", "Soft Texture"],
    fresh: true,
  },
  {
    name: "Farmhouse Cheese",
    emoji: "🧈",
    description:
      "Aged in our cellar with a rich, earthy character. Perfect for boards and bakes.",
    tags: ["Aged", "Artisan"],
  },
  {
    name: "Cultured Butter",
    emoji: "🧈",
    description:
      "Hand-churned, lightly salted butter with the deep golden colour of pasture milk.",
    tags: ["Hand-churned"],
  },
  {
    name: "Ghee",
    emoji: "🍯",
    description:
      "Slow-simmered bilona ghee with a nutty aroma — straight from our kitchen.",
    tags: ["Bilona", "Aromatic"],
  },
  {
    name: "Buttermilk",
    emoji: "🥤",
    description:
      "Light, refreshing buttermilk lightly spiced — cooling and gut-friendly.",
    tags: ["Fresh", "Daily"],
    fresh: true,
  },
  {
    name: "Sweet Curd",
    emoji: "🍮",
    description:
      "A traditional sweetened curd dessert, set in clay pots for an earthy aroma.",
    tags: ["Dessert", "Traditional"],
  },
];

export default function Products() {
  const [enquiry, setEnquiry] = useState(null);

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <span className="crumb">Our Range</span>
          <h1>Pure Dairy, Crafted Daily</h1>
          <p>
            Every product on this page is made from this morning's milking. Tap{" "}
            <strong>Enquiry</strong> on any item and we'll get back with pricing
            and delivery options for your area.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="products-grid">
            {PRODUCTS.map((p) => (
              <ProductCard key={p.name} product={p} onEnquire={setEnquiry} />
            ))}
          </div>
        </div>
      </section>

      {enquiry && <EnquiryModal product={enquiry} onClose={() => setEnquiry(null)} />}
    </>
  );
}
