import { Link } from "@tanstack/react-router";
import GrazingCowAnimation from "../components/GrazingCowAnimation";
import "../css/home.css";

const FEATURES = [
  { icon: "🌿", title: "100% Organic", desc: "No hormones, no preservatives — just pure dairy the way nature intended." },
  { icon: "🐄", title: "Healthy Cows",  desc: "Free-grazing herds raised ethically on chemical-free pasture." },
  { icon: "🚚", title: "Fresh Daily Delivery", desc: "From our pasture to your doorstep every morning before sunrise." },
  { icon: "📦", title: "Hygienic Packaging",   desc: "Glass-bottled and food-grade sealed in our certified clean dairy." },
  { icon: "🌾", title: "Farm Fresh Products",  desc: "Crafted in small batches the same day they're collected." },
];

const FEATURED = [
  { emoji: "🥛", name: "Fresh Milk", desc: "Creamy, hand-bottled cow milk delivered within hours of milking." },
  { emoji: "🥣", name: "Curd",       desc: "Thick, set curd cultured slowly using traditional methods." },
  { emoji: "🧀", name: "Paneer",     desc: "Soft, fresh paneer made daily — no additives, just milk and lemon." },
  { emoji: "🧈", name: "Cheese",     desc: "Aged farmhouse cheese with a rich, earthy character." },
];

export default function Home() {
  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero-bg">
          <GrazingCowAnimation caption="" />
        </div>
        <div className="container hero-inner">
          <div>
            <span className="hero-eyebrow"><span className="dot" /> Mukti Dairy Farm</span>
            <h1>
              Fresh Organic Milk <br />
              From <span className="accent">Healthy Farms</span>
            </h1>
            <p className="lead">
              Pure, hand-bottled dairy from our family-run organic farm. Tasted in
              every sip — the warmth of pasture, the honesty of village care, and
              the freshness of this morning's milking.
            </p>
            <div className="hero-actions">
              <Link to="/products" className="btn btn-primary">Explore Products</Link>
              <Link to="/contact" className="btn btn-outline">Visit Farm</Link>
            </div>
            <div className="hero-stats">
              <div className="hero-stat"><strong>120+</strong><span>Happy Cows</span></div>
              <div className="hero-stat"><strong>15K+</strong><span>Litres / Month</span></div>
              <div className="hero-stat"><strong>4.9★</strong><span>Customer Love</span></div>
            </div>
          </div>

          <div className="hero-visual">
            <GrazingCowAnimation caption="Live from our pasture" />
            <div className="glass-card glass-card-1">
              <div className="icon">🥛</div>
              <div>
                <div className="label">Today's Milking</div>
                <div className="value">412 Litres</div>
              </div>
            </div>
            <div className="glass-card glass-card-2">
              <div className="icon">🌅</div>
              <div>
                <div className="label">Delivered By</div>
                <div className="value">7:00 AM</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Why Choose Mukti</h2>
          <p className="section-subtitle">
            Honest dairy farming — rooted in the village, refined for the modern table.
          </p>
          <div className="why-grid">
            {FEATURES.map((f) => (
              <div className="why-card" key={f.title}>
                <div className="why-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="section" style={{ background: "linear-gradient(180deg, #fbf6e7 0%, #eaf6e9 100%)" }}>
        <div className="container">
          <h2 className="section-title">Featured Products</h2>
          <p className="section-subtitle">Crafted in small batches. Bottled the same morning.</p>
          <div className="products-grid">
            {FEATURED.map((p) => (
              <article className="product-card" key={p.name}>
                <div className="product-thumb">
                  <span className="product-badge">Organic</span>
                  <span className="product-emoji">{p.emoji}</span>
                </div>
                <div className="product-body">
                  <h3>{p.name}</h3>
                  <p>{p.desc}</p>
                  <Link to="/products" className="btn-enquiry">Enquiry</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ORGANIC FARMING */}
      <section className="section">
        <div className="container split">
          <div className="split-media"><GrazingCowAnimation caption="Organic pastures" /></div>
          <div>
            <h2>Organic Farming, the Mukti Way</h2>
            <p>
              Our cows graze freely on chemical-free pasture, drink fresh
              spring water, and live by the rhythms of the sun. No shortcuts —
              just slow, careful farming that respects the land and the herd.
            </p>
            <ul>
              <li>Pesticide-free fodder grown on-farm</li>
              <li>Rotational grazing for soil health</li>
              <li>Veterinary-certified herd, every month</li>
            </ul>
          </div>
        </div>
      </section>

      {/* HEALTHY COWS */}
      <section className="section" style={{ background: "linear-gradient(180deg, #eaf6e9 0%, #fbf6e7 100%)" }}>
        <div className="container split reverse">
          <div className="split-media"><GrazingCowAnimation caption="Happy herd" /></div>
          <div>
            <h2>Healthy Cows, Honest Milk</h2>
            <p>
              A happy cow gives the richest milk. Each animal in our herd has a
              name, a daily health log, and plenty of space to roam. We never
              use artificial hormones — ever.
            </p>
            <ul>
              <li>Spacious open-pasture sheds</li>
              <li>Hormone-free, ethically raised</li>
              <li>Daily health & nutrition checks</li>
            </ul>
          </div>
        </div>
      </section>

      {/* DAILY DELIVERY */}
      <section className="section">
        <div className="container">
          <div className="delivery">
            <div>
              <h2>Fresh Dairy. Delivered Daily.</h2>
              <p>
                Subscribe to our morning route and wake up to glass-bottled,
                farm-fresh milk on your doorstep — every single day.
              </p>
              <Link to="/contact" className="btn btn-primary">Start Daily Delivery</Link>
            </div>
            <div style={{ textAlign: "center", fontSize: "5rem" }}>🚚</div>
          </div>
        </div>
      </section>

      {/* TRUST */}
      <section className="section">
        <div className="container">
          <div className="trust">
            <p className="trust-quote">
              The taste reminded me of my grandmother's village. Thick, creamy,
              and honest — Mukti Dairy has become a part of our family's morning.
            </p>
            <div className="trust-author">
              Ananya Rao
              <small>Loyal customer since 2022</small>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
