import { useState } from "react";
import "../css/contact.css";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", mobile: "", address: "", message: "" });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Please enter your name";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Enter a valid email address";
    if (!/^\d{10}$/.test(form.mobile.replace(/\D/g, ""))) e.mobile = "Enter a 10-digit mobile";
    if (!form.address.trim()) e.address = "Address is required";
    if (!form.message.trim()) e.message = "Add a short message";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSuccess(true);
    setForm({ name: "", email: "", mobile: "", address: "", message: "" });
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <span className="crumb">Get in Touch</span>
          <h1>Visit Our Farm, or Drop Us a Line</h1>
          <p>
            Whether you'd like to subscribe for daily delivery, tour our pasture,
            or just say hello — we'd love to hear from you.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="contact-grid">
            <div className="contact-info">
              <h2>Reach Mukti Dairy</h2>
              <p className="lead">Our farm gates are open every day from sunrise to sunset.</p>

              <div className="info-row">
                <div className="info-ic">📍</div>
                <div>
                  <div className="info-lbl">Address</div>
                  <div className="info-val">Village Road, Mukti Nagar, Karnataka 560001</div>
                </div>
              </div>
              <div className="info-row">
                <div className="info-ic">📞</div>
                <div>
                  <div className="info-lbl">Phone</div>
                  <div className="info-val">+91 98765 43210</div>
                </div>
              </div>
              <div className="info-row">
                <div className="info-ic">✉</div>
                <div>
                  <div className="info-lbl">Email</div>
                  <div className="info-val">hello@muktidairy.farm</div>
                </div>
              </div>
              <div className="info-row">
                <div className="info-ic">🕒</div>
                <div>
                  <div className="info-lbl">Hours</div>
                  <div className="info-val">5:00 AM – 8:00 PM, all days</div>
                </div>
              </div>
            </div>

            <div className="contact-form">
              <h2>Send us a message</h2>
              <p className="sub">We typically reply within a few hours.</p>

              {success && (
                <div className="success-banner">
                  ✓ Message sent — our team will get back to you shortly.
                </div>
              )}

              <form onSubmit={submit} noValidate>
                <div className="field">
                  <label>Name</label>
                  <input value={form.name} onChange={update("name")} placeholder="Your full name" />
                  {errors.name && <div className="err">{errors.name}</div>}
                </div>
                <div className="field">
                  <label>Email</label>
                  <input value={form.email} onChange={update("email")} placeholder="you@example.com" />
                  {errors.email && <div className="err">{errors.email}</div>}
                </div>
                <div className="field">
                  <label>Mobile Number</label>
                  <input value={form.mobile} onChange={update("mobile")} placeholder="10-digit number" inputMode="numeric" />
                  {errors.mobile && <div className="err">{errors.mobile}</div>}
                </div>
                <div className="field">
                  <label>Address</label>
                  <input value={form.address} onChange={update("address")} placeholder="Delivery address" />
                  {errors.address && <div className="err">{errors.address}</div>}
                </div>
                <div className="field">
                  <label>Message</label>
                  <textarea value={form.message} onChange={update("message")} placeholder="How can we help?" />
                  {errors.message && <div className="err">{errors.message}</div>}
                </div>
                <button type="submit" className="btn btn-primary" style={{ width: "100%" }}>
                  Send Message
                </button>
              </form>
            </div>
          </div>

          <div className="map-placeholder">
            <div className="map-pin">📍 Mukti Dairy Farm — Village Road</div>
          </div>
        </div>
      </section>
    </>
  );
}
