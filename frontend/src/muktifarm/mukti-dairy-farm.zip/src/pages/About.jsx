import GrazingCowAnimation from "../components/GrazingCowAnimation";
import "../css/about.css";

const STEPS = [
  { t: "Pasture First", d: "Our day begins at sunrise, with the herd grazing freely on chemical-free pasture." },
  { t: "Gentle Milking", d: "Stress-free, hand-supervised milking — no machines forced on tired cows." },
  { t: "Same-Hour Bottling", d: "Milk is cooled, filtered and glass-bottled within the hour, untouched by additives." },
  { t: "Hygienic Packaging", d: "Each bottle is sealed in our certified clean dairy and quality-checked by hand." },
  { t: "Morning Delivery", d: "Our route begins at 5 AM so your milk reaches you before breakfast." },
  { t: "Returned, Sanitized, Reused", d: "We collect empty bottles the next day, sanitize and reuse — gentle on the planet." },
];

export default function About() {
  return (
    <>
      <section className="page-hero">
        <div className="container">
          <span className="crumb">About Mukti</span>
          <h1>A Village Dairy with a Modern Heart</h1>
          <p>
            Mukti Dairy Farm was born from a simple belief — that the milk we
            grew up drinking, fresh from a known cow, should be available to
            every family. Today, we deliver that same honest dairy to thousands
            of homes.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container about-story">
          <div className="split-media"><GrazingCowAnimation caption="Where it all began" /></div>
          <div>
            <h2>Our Story</h2>
            <p>
              Three generations of dairy farmers, one shared promise: never
              compromise on the cow, the milk, or the customer. What began as a
              small family stable with six cows is now a 120-strong herd serving
              the whole region — but every bottle is still treated like it's
              going to our own family's table.
            </p>
            <p>
              We don't believe in shortcuts. No hormones, no preservatives, no
              powdered milk reconstitution — just fresh, traceable dairy from
              cows we know by name.
            </p>
          </div>
        </div>
      </section>

      <section className="section" style={{ background: "linear-gradient(180deg, #eaf6e9 0%, #fbf6e7 100%)" }}>
        <div className="container">
          <h2 className="section-title">Mission & Vision</h2>
          <p className="section-subtitle">Built on care for the cow, the customer, and the soil.</p>
          <div className="mv-grid">
            <div className="mv-card">
              <div className="mv-icon">🎯</div>
              <h3>Our Mission</h3>
              <p>
                To bring pure, organic, hormone-free dairy to every doorstep —
                while raising our herd with the kindness they deserve.
              </p>
            </div>
            <div className="mv-card">
              <div className="mv-icon">🌅</div>
              <h3>Our Vision</h3>
              <p>
                A world where every glass of milk is honest — traceable to a
                farm, a cow, a morning. We want to make that the standard, not
                the exception.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Organic Dairy Process</h2>
          <p className="section-subtitle">From pasture to your doorstep in less than 12 hours.</p>
          <div className="timeline">
            {STEPS.map((s, i) => (
              <div className="tl-step" key={s.t} style={{ animationDelay: `${i * 0.08}s` }}>
                <span className="tl-num">Step 0{i + 1}</span>
                <h4>{s.t}</h4>
                <p>{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" style={{ background: "linear-gradient(180deg, #fbf6e7 0%, #eaf6e9 100%)" }}>
        <div className="container">
          <div className="mv-grid">
            <div className="mv-card">
              <div className="mv-icon">🐄</div>
              <h3>Healthy Cow Care</h3>
              <p>Veterinary checks, open pasture, balanced nutrition and daily exercise — happy cows make better milk.</p>
            </div>
            <div className="mv-card">
              <div className="mv-icon">📦</div>
              <h3>Hygienic Packaging</h3>
              <p>Glass bottles sterilized in-house, sealed in a certified clean dairy and hand-checked before dispatch.</p>
            </div>
            <div className="mv-card">
              <div className="mv-icon">🚚</div>
              <h3>Daily Delivery</h3>
              <p>An early-morning route that ensures your dairy arrives before breakfast, every single day of the week.</p>
            </div>
            <div className="mv-card">
              <div className="mv-icon">💚</div>
              <h3>Customer Trust</h3>
              <p>Over 5,000 families across the region rely on Mukti for their daily dairy — and we never take that lightly.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
