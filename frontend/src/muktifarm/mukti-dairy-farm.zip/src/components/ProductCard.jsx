import "../css/products.css";

export default function ProductCard({ product, onEnquire }) {
  return (
    <article className="product-card">
      <div className="product-thumb">
        <span className={`product-badge ${product.fresh ? "fresh" : ""}`}>
          {product.fresh ? "Fresh" : "Organic"}
        </span>
        <span className="product-emoji" role="img" aria-label={product.name}>
          {product.emoji}
        </span>
      </div>
      <div className="product-body">
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <div className="product-tags">
          {product.tags.map((t) => (
            <span key={t} className="product-tag">{t}</span>
          ))}
        </div>
        <button className="btn-enquiry" onClick={() => onEnquire(product.name)}>
          Enquiry
        </button>
      </div>
    </article>
  );
}
