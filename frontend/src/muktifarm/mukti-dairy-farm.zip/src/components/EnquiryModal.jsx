import { useEffect, useState } from "react";
import "../css/modal.css";

export default function EnquiryModal({ product, onClose }) {
  const [form, setForm] = useState({ name: "", mobile: "", address: "", message: "" });
  const [errors, setErrors] = useState({});
  const [done, setDone] = useState(false);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Please enter your name";
    if (!/^\d{10}$/.test(form.mobile.replace(/\D/g, "")))
      e.mobile = "Enter a valid 10-digit mobile number";
    if (!form.address.trim()) e.address = "Address is required";
    if (!form.message.trim()) e.message = "Add a short message";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setDone(true);
    setTimeout(onClose, 1800);
  };

  return (
    <div
      className="modal-backdrop"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="enq-title">
        <button className="modal-close" onClick={onClose} aria-label="Close">×</button>

        {done ? (
          <div className="modal-success">
            <div className="check">✓</div>
            <h3>Enquiry Sent!</h3>
            <p className="modal-sub">
              Thank you for your interest in {product}. We'll contact you shortly.
            </p>
          </div>
        ) : (
          <>
            <span className="pill">Product Enquiry</span>
            <h3 id="enq-title">Enquire about {product}</h3>
            <p className="modal-sub">
              Share your details and our team will reach out within a few hours.
            </p>

            <form onSubmit={submit} noValidate>
              <input type="hidden" name="product" value={product} />

              <div className="field">
                <label>Name</label>
                <input value={form.name} onChange={update("name")} placeholder="Your full name" />
                {errors.name && <div className="err">{errors.name}</div>}
              </div>

              <div className="field">
                <label>Mobile Number</label>
                <input
                  value={form.mobile}
                  onChange={update("mobile")}
                  placeholder="10-digit number"
                  inputMode="numeric"
                />
                {errors.mobile && <div className="err">{errors.mobile}</div>}
              </div>

              <div className="field">
                <label>Address</label>
                <input
                  value={form.address}
                  onChange={update("address")}
                  placeholder="Delivery address"
                />
                {errors.address && <div className="err">{errors.address}</div>}
              </div>

              <div className="field">
                <label>Message</label>
                <textarea
                  value={form.message}
                  onChange={update("message")}
                  placeholder={`Tell us about the quantity & frequency you need for ${product}`}
                />
                {errors.message && <div className="err">{errors.message}</div>}
              </div>

              <button type="submit" className="btn-submit">Send Enquiry</button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
