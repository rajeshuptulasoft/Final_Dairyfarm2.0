import { Link } from "@tanstack/react-router";
import "../css/footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="brand">
              <span className="nav-logo-badge">M</span>
              Mukti Dairy Farm
            </div>
            <p>
              Pure, organic dairy products from our family farm — delivered
              fresh to your doorstep every morning.
            </p>
            <div className="socials">
              <a className="social-icon" href="#" aria-label="Facebook">
                <svg viewBox="0 0 24 24"><path d="M13 22v-8h3l1-4h-4V7.5c0-1.2.4-2 2-2h2V2.1c-.6-.1-1.7-.1-2.8-.1C11.5 2 10 4 10 7v3H7v4h3v8h3z"/></svg>
              </a>
              <a className="social-icon" href="#" aria-label="Instagram">
                <svg viewBox="0 0 24 24"><path d="M12 2.2c3.2 0 3.6 0 4.8.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.2.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.2.1-1.6.1-4.8.1s-3.6 0-4.8-.1c-1.2-.1-1.8-.3-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.2-.4-.4-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.8c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 5.4A4.4 4.4 0 1012 16.4 4.4 4.4 0 0012 7.6zm5.6-.3a1 1 0 100 2 1 1 0 000-2zM12 9.4a2.6 2.6 0 110 5.2 2.6 2.6 0 010-5.2z"/></svg>
              </a>
              <a className="social-icon" href="#" aria-label="Twitter">
                <svg viewBox="0 0 24 24"><path d="M22 5.9c-.7.3-1.5.6-2.3.7.8-.5 1.5-1.3 1.8-2.2-.8.5-1.7.8-2.6 1A4.1 4.1 0 0011.8 9c0 .3 0 .6.1.9C8.3 9.7 5.1 8 3 5.5c-.4.6-.6 1.3-.6 2.1 0 1.4.7 2.7 1.8 3.4-.6 0-1.2-.2-1.7-.5v.1c0 2 1.4 3.6 3.3 4-.3.1-.7.2-1.1.2-.3 0-.5 0-.8-.1.5 1.6 2 2.8 3.8 2.8A8.2 8.2 0 012 19a11.6 11.6 0 006.3 1.8c7.5 0 11.7-6.3 11.7-11.7v-.5c.8-.5 1.5-1.2 2-2z"/></svg>
              </a>
            </div>
          </div>

          <div>
            <h4>Quick Links</h4>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/products">Products</Link></li>
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h4>Products</h4>
            <ul>
              <li>Fresh Milk</li>
              <li>Curd</li>
              <li>Paneer</li>
              <li>Cheese</li>
            </ul>
          </div>

          <div>
            <h4>Contact</h4>
            <ul>
              <li>📍 Village Road, Mukti Nagar</li>
              <li>📞 +91 98765 43210</li>
              <li>✉ hello@muktidairy.farm</li>
              <li>🕒 5 AM – 8 PM, Daily</li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          © {new Date().getFullYear()} Mukti Dairy Farm. Crafted with care from our pastures.
        </div>
      </div>
    </footer>
  );
}
